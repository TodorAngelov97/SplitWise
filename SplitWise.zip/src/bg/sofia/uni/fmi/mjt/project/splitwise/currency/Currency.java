package bg.sofia.uni.fmi.mjt.project.splitwise.currency;

public interface Currency {
	public double getRate();
}
