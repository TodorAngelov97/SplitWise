package bg.sofia.uni.fmi.mjt.project.splitwise.currency;

public class DollarRate {
	private Dollars rates;

	public DollarRate(Dollars rates) {
		this.rates = rates;
	}

	public double getRate() {
		return rates.getRate();
	}
}
