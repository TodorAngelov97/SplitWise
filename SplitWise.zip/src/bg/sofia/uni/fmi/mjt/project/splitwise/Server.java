package bg.sofia.uni.fmi.mjt.project.splitwise;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Type;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;

public class Server {

	static final int PORT = 8080;
	static final double INITIAL_RATE = 1;
	private static final String FILE_NAME = "resources/Output.json";

	private ServerSocket socketOfServer;
	private Map<String, Socket> activeUsers;
	private Set<UserProfile> justProfiles;
	private Map<String, UserProfile> allProfiles;
	private Map<String, Map<String, Friend>> friendsList;
	private Map<String, Map<String, Group>> groups;
	private Map<String, Notifications> usersNotifications;
	private Map<String, Double> ratesOfCurrencies;

	public Server(ServerSocket socketOfServer) {
		initializeConstructor(socketOfServer);
	}

	public double getRate(String username) {
		return ratesOfCurrencies.get(username);
	}

	public void setRate(String username, double rate) {
		ratesOfCurrencies.put(username, rate);
	}

	private void initializeConstructor(ServerSocket socketOfServer) {
		this.socketOfServer = socketOfServer;
		activeUsers = new HashMap<>();
		justProfiles = new HashSet<>();
		allProfiles = new HashMap<>();
		friendsList = new HashMap<>();
		groups = new HashMap<>();
		usersNotifications = new HashMap<>();
		ratesOfCurrencies = new HashMap<>();
		loadUser();

	}

	public synchronized void addFriendNotification(String username, String notification) {
		usersNotifications.get(username).addFrindNotification(notification);
	}

	public synchronized void addGroupNotificatioon(String username, String notification) {
		usersNotifications.get(username).addGroupNotification(notification);
	}

	private synchronized String getUserNotifications(String username) {
		return usersNotifications.get(username).getAllNotifications();
	}

	private synchronized boolean hasNotifications(String username) {
		return !(usersNotifications.get(username).isEmpty());
	}

	public synchronized void printUserNotifications(PrintWriter writer, String username) {
		if (hasNotifications(username)) {
			writer.println(getUserNotifications(username));
		} else {
			String message = "No notifications to show";
			writer.println(message);
		}
	}

	public synchronized boolean isActive(String username) {
		return activeUsers.containsKey(username);
	}

	public synchronized Socket getSokcet(String username) {
		return activeUsers.get(username);
	}

	public synchronized boolean isContained(String user) {
		return allProfiles.containsKey(user);

	}

	public synchronized boolean isCorrectPassword(String user, String password) {
		return allProfiles.get(user).getPassword().equals(password);
	}

	public synchronized String getProfileNames(String username) {
		return allProfiles.get(username).getProfileNames();
	}

	public synchronized Map<String, Friend> getFriendsList(String username) {
		return friendsList.get(username);
	}

	public synchronized void removeUser(String username) {
		activeUsers.remove(username);
	}

	public synchronized Map<String, Group> getGroupsOfUser(String username) {
		return groups.get(username);
	}

	public synchronized boolean isLogedIn(String name, String password, PrintWriter writer) {

		if (!isContained(name)) {
			writer.println("Nonexitent user");
			return false;
		} else if (!isCorrectPassword(name, password)) {
			writer.println("Incorrect password");
			return false;
		}
		return true;
	}

	private boolean isFileEmpty(File file) {
		return file.length() == 0;
	}

	private void addUsers(Set<UserProfile> users) {
		for (UserProfile user : users) {
			addNewUser(user.getUsername(), user);
		}
	}

	public synchronized void addNewUser(String username, UserProfile newUserProfile) {
		justProfiles.add(newUserProfile);
		allProfiles.put(username, newUserProfile);
		friendsList.put(username, new HashMap<String, Friend>());
		groups.put(username, new HashMap<String, Group>());
		usersNotifications.put(username, new Notifications());
		ratesOfCurrencies.put(username, INITIAL_RATE);

	}

	private void loadUser() {

		try {
			File file = new File(FILE_NAME);
			if (!isFileEmpty(file)) {

				Gson gson = new Gson();
				Type type = new TypeToken<HashSet<UserProfile>>() {
				}.getType();
				JsonReader readerForUsers = new JsonReader(new FileReader(file));
				Set<UserProfile> data = gson.fromJson(readerForUsers, type);
				addUsers(data);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public synchronized void saveUserInFile() {

		try (Writer writer = new FileWriter(FILE_NAME)) {
			Gson gson = new GsonBuilder().create();
			gson.toJson(justProfiles, writer);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void execute() {

		System.out.printf("Server is running on localhost:%d%n", PORT);
		try {
			while (true) {
				Socket socket = socketOfServer.accept();
				startNewThreadForUser(socket);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				socketOfServer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public synchronized void addNewActiveUser(String username, Socket socket) {
		activeUsers.put(username, socket);
	}

	private void startNewThreadForUser(Socket socket) {
		ClientConnectionRunnable runnable = new ClientConnectionRunnable(socket, this);
		new Thread(runnable).start();
	}

	public static void main(String[] args) {
		try {
			Server s = new Server(new ServerSocket(PORT));

			s.execute();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
