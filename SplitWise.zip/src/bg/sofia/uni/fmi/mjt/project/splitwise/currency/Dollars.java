package bg.sofia.uni.fmi.mjt.project.splitwise.currency;

public class Dollars implements Currency {

	private double USD;

	public Dollars(double USD) {
		this.USD = USD;
	}

	@Override
	public double getRate() {
		return USD;
	}

}
