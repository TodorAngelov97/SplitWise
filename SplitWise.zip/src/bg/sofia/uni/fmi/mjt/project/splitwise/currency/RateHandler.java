package bg.sofia.uni.fmi.mjt.project.splitwise.currency;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse.BodyHandlers;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

public class RateHandler {
	private String from;
	private String to;

	public RateHandler(String from, String to) {
		this.from = from;
		this.to = to;
	}

	private String getJson() throws IOException, InterruptedException {
		HttpClient client = HttpClient.newHttpClient();
		String req = String.format("https://api.exchangeratesapi.io/latest?base=%s&symbols=%s", from, to);
		HttpRequest request = HttpRequest.newBuilder().uri(URI.create(req)).build();
		return client.send(request, BodyHandlers.ofString()).body();
	}

	public double getRate() {

		Gson gson = new Gson();

		// return gson.fromJson(getJson(), Rate.class).getRate();
		try {
			if (to.equals("EUR")) {
				return gson.fromJson(getJson(), EuroRate.class).getRate();

			} else if (to.equals("USD")) {
				return gson.fromJson(getJson(), DollarRate.class).getRate();
			}
			return gson.fromJson(getJson(), LevaRate.class).getRate();
		} catch (JsonSyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	public static void main(String[] args) {
		System.out.println(new RateHandler("EYR", "USD").getRate());
	}

}
