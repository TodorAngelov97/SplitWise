package bg.sofia.uni.fmi.mjt.project.splitwise.currency;

public class EuroRate {
	private Euro rates;

	public EuroRate(Euro rates) {
		this.rates = rates;
	}

	public double getRate() {
		return rates.getRate();
	}
}
